// nav.js
function dropdown() {

  // Get DOM elements.
  const dropdownMenu = document.getElementById("dropdownMenu");

  // Toggle the dropdown menu.
  dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";

}
