<?php require '../functions.php';

// Load location.
locationPage();