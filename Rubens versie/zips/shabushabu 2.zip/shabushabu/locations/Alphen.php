<?php require '../functions.php';

// Store posted values in session.
locationPage();