<nav>
    <div class="left-column">
        <img src="images/Shabu_Shabu_Logo.png" alt="ShabuShabu Logo">
    </div>
    <div class="right-column">
        <a href="index.php">Home</a>
        <a href="#">Over ons</a>
        <a href="form.php">Reserveren</a>
        <a href="#">Contact</a>
    </div>
</nav>