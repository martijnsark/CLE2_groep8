<?php

// Get the current HTTP host
$hostServer = $_SERVER['HTTP_HOST'];

// Check if the application is running on localhost
if ($hostServer == 'localhost') {

    // Local database configuration
    $host     = 'db';
    $user     = 'shabushabu';
    $password = 'qwerty';
    $database = 'shabushabu';

} else {
    // Online (remote) database configuration
    $host       = "localhost";
    $user       = "1100105";
    $password   = "duethooy";
    $database   = "1100105";
}

